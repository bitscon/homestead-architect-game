import { supabase } from '@/integrations/supabase/client';
import type { Database } from '@/integrations/supabase/types';

export interface Property {
  id: string;
  user_id: string;
  name: string;
  size_acres: number;
  location: string;
  climate_zone?: string | null;
  soil_type?: string | null;
  soil_ph?: number | null;
  sun_exposure?: string | null;
  water_sources?: string[] | null;
  created_at: string;
  updated_at: string;
}

export interface PropertyInsert {
  name: string;
  size_acres: number;
  location: string;
  climate_zone?: string | null;
  soil_type?: string | null;
  soil_ph?: number | null;
  sun_exposure?: string | null;
  water_sources?: string[] | null;
}

export interface PropertyUpdate {
  name?: string;
  size_acres?: number;
  location?: string;
  climate_zone?: string | null;
  soil_type?: string | null;
  soil_ph?: number | null;
  sun_exposure?: string | null;
  water_sources?: string[] | null;
}

export async function getProperties(userId: string) {
  const { data, error } = await supabase
    .from('properties')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data as Property[];
}

export async function getPropertyById(id: string, userId: string) {
  const { data, error } = await supabase
    .from('properties')
    .select('*')
    .eq('id', id)
    .eq('user_id', userId)
    .maybeSingle();

  if (error) throw error;
  return data as Property | null;
}

export async function createProperty(userId: string, property: PropertyInsert) {
  const { data, error } = await supabase
    .from('properties')
    .insert({
      ...property,
      user_id: userId,
    })
    .select()
    .single();

  if (error) throw error;
  return data as Property;
}

export async function updateProperty(id: string, userId: string, property: PropertyUpdate) {
  const { data, error } = await supabase
    .from('properties')
    .update(property)
    .eq('id', id)
    .eq('user_id', userId)
    .select()
    .single();

  if (error) throw error;
  return data as Property;
}

export async function deleteProperty(id: string, userId: string) {
  const { error } = await supabase
    .from('properties')
    .delete()
    .eq('id', id)
    .eq('user_id', userId);

  if (error) throw error;
}
